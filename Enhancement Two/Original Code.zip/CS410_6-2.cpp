#include <iostream>

using namespace std;

void displayMenu(){
	cout << "-----------------" << endl;
	cout << "1) Subtract" << endl; //changed from add
	cout << "2) Add" << endl; //changed from subtract
	cout << "3) Divide" << endl; //changed from multiply
	cout << "4) Exit" << endl;
	cout << "-----------------" << endl;
}

int main() {
	int choice = 0;
	displayMenu();
	cin >> choice;

	while (choice != 4) { //changed from 5
		int num1;
		int num2;

		cout << "Enter first number:" << endl; //added to prompt user
		cin >> num1;
		cout << "Enter second number:" << endl; //added to prompt user
		cin >> num2;

		if (choice == 1) {
			cout << num1 << " - " << num2 << " = " << num1 - num2 << endl;
		}

		else if (choice == 2) {
			cout << num1 << " + " << num2 << " = " << num1 + num2 << endl; //changed - to +
		}

		else if (choice == 3) {
			cout << num1 << " / " << num2 << " = " << num1 / num2 << endl; //changed - to /
		}

		else {
			cout << "Enter valid choice." << endl; //added to give user another chance
		}

		displayMenu();
		cin >> choice;
	}
}